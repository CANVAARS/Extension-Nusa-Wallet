// Chrome (service worker) memuat core lewat importScripts; Firefox (event page) memuatnya lewat background.scripts di manifest.
if (typeof importScripts === 'function') importScripts('lib/nusa-core.js');
const ext = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome; // Firefox: browser.*, Chrome/Edge: chrome.*
const C = NusaCore;
const DEFAULT_CFG = { explorer: 'https://explorer.nusacoin.org', api: 'https://api.nusacoin.org', utxoTemplate: '', fee: '0.0001', autoLockMin: 15 };
const getLocal = async k => (await ext.storage.local.get(k))[k];
const err = (code, message) => ({ error: { code, message } });

async function cfg() { return Object.assign({}, DEFAULT_CFG, await getLocal('cfg')); }
async function account() { return getLocal('account'); }               // { address, pubkey, type } (publik)
async function isUnlocked() { return !!(await ext.storage.session.get('wif')).wif; }
async function perms() { return (await getLocal('perms')) || {}; }

// ---- auto-lock ----
ext.alarms.onAlarm.addListener(a => { if (a.name === 'autolock') ext.storage.session.remove('wif'); });
ext.runtime.onMessage.addListener((m, sender, sendResponse) => {
  (async () => {
    const fromExt = sender.id === ext.runtime.id && (sender.url || '').startsWith(ext.runtime.getURL(''));
    if (['touch', 'get-pending', 'resolve-pending'].includes(m.type) && !fromExt) return sendResponse(err(4100, 'Ditolak'));
    if (m.type === 'touch') { const c = await cfg(); ext.alarms.create('autolock', { delayInMinutes: Math.max(1, Number(c.autoLockMin) || 15) }); return sendResponse({}); }
    if (m.type === 'dapp-request') {
      if (sender.id !== ext.runtime.id || !sender.tab) return sendResponse(err(4100, 'Pengirim tidak valid'));
      return sendResponse(await handleDapp(m.method, m.params || {}, sender.origin || new URL(sender.tab.url).origin));
    }
    if (m.type === 'get-pending') { const p = (await ext.storage.session.get('pending')).pending || {}; return sendResponse(p[m.id] || null); }
    if (m.type === 'resolve-pending') { return sendResponse(await resolvePending(m.id, m.approved, m.result, m.message)); }
    sendResponse({});   // termasuk 'ping'
  })();
  return true;
});

// ---- permintaan DApp ----
const waiters = new Map(); // id -> sendResponse resolver (bertahan selama service worker hidup)

async function handleDapp(method, params, origin) {
  const acc = await account();
  if (!acc) return err(4100, 'Wallet belum dibuat. Buka ekstensi Nusa Wallet.');
  const allowed = !!(await perms())[origin];
  if (method === 'nux_disconnect') { const p = await perms(); delete p[origin]; await ext.storage.local.set({ perms: p }); return { result: true }; }
  if (method === 'nux_connect' && allowed) return { result: { address: acc.address, publicKey: acc.pubkey } };
  if (method === 'nux_getAddress') return allowed ? { result: acc.address } : err(4100, 'Situs belum terhubung. Panggil connect() dulu.');
  if (method === 'nux_getBalance') {
    if (!allowed) return err(4100, 'Situs belum terhubung.');
    try { return { result: await C.fetchBalance((await cfg()).explorer, acc.address) }; } catch (e) { return err(-32603, e.message); }
  }
  if (method === 'nux_connect' || method === 'nux_signMessage' || method === 'nux_sendTransaction' || method === 'nux_sendData' || method === 'nux_signTransaction') {
    if (method !== 'nux_connect' && !allowed) return err(4100, 'Situs belum terhubung.');
    if (method === 'nux_signMessage' && typeof params.message !== 'string') return err(-32602, 'message harus string');
    if (method === 'nux_sendTransaction') {
      try { C.addressToScriptHex(params.to); } catch (e) { return err(-32602, e.message); }
      const a = Number(params.amount); if (!(a > 0)) return err(-32602, 'amount harus > 0 (dalam NUX)');
    }
    if (method === 'nux_signTransaction') {
      if (!Array.isArray(params.inputs) || !Array.isArray(params.outputs)) return err(-32602, 'inputs dan outputs harus berupa array');
      if (params.inputs.length > 800 || params.outputs.length > 800) return err(-32602, 'Transaksi terlalu besar');
    }
    if (method === 'nux_sendData') {
      try { params.hex = dataToHex(params.data, params.encoding); } catch (e) { return err(-32602, e.message); }
    }
    return requestApproval(method, params, origin, acc);
  }
  return err(4200, 'Method tidak didukung');
}

function dataToHex(data, encoding) {
  let bytes;
  if (encoding === 'hex') { if (!/^([0-9a-fA-F]{2})+$/.test(data)) throw new Error('Data hex tidak valid.'); bytes = C.hexToBytes(data); }
  else if (!encoding || encoding === 'utf8') bytes = new TextEncoder().encode(data);
  else throw new Error("encoding harus 'utf8' atau 'hex'");
  if (!bytes.length || bytes.length > C.MAX_OPRETURN) throw new Error(`Data harus 1-${C.MAX_OPRETURN} byte (sekarang ${bytes.length}).`);
  return C.bytesToHex(bytes);
}

async function requestApproval(method, params, origin, acc) {
  const id = crypto.randomUUID();
  const store = (await ext.storage.session.get('pending')).pending || {};
  store[id] = { id, method, params, origin, address: acc.address };
  await ext.storage.session.set({ pending: store });
  const win = await ext.windows.create({ url: ext.runtime.getURL('popup.html#approve=' + id), type: 'popup', width: 400, height: 640 });
  return new Promise(resolve => {
    waiters.set(id, resolve);
    const onRemoved = wid => { if (win && wid === win.id) { ext.windows.onRemoved.removeListener(onRemoved); finish(id, err(4001, 'Pengguna menutup jendela persetujuan')); } };
    ext.windows.onRemoved.addListener(onRemoved);
  });
}
async function finish(id, response) {
  const w = waiters.get(id); if (!w) return; waiters.delete(id);
  const store = (await ext.storage.session.get('pending')).pending || {}; delete store[id]; await ext.storage.session.set({ pending: store });
  w(response);
}
async function resolvePending(id, approved, result, message) {
  const store = (await ext.storage.session.get('pending')).pending || {}, req = store[id];
  if (!req) return { ok: false };
  if (!approved) { await finish(id, err(4001, message || 'Ditolak pengguna')); return { ok: true }; }
  if (req.method === 'nux_connect') {
    const p = await perms(); p[req.origin] = Date.now(); await ext.storage.local.set({ perms: p });
    const acc = await account(); await finish(id, { result: { address: acc.address, publicKey: acc.pubkey } });
  } else await finish(id, { result });
  return { ok: true };
}
