(() => {
  'use strict';
  const ext = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome; // Firefox: browser.*, Chrome/Edge: chrome.*
  const C = NusaCore, C_SEED = NusaSeed, $ = id => document.getElementById(id);
  const DEFAULT_CFG = { explorer: 'https://explorer.nusacoin.org', api: 'https://api.nusacoin.org', utxoTemplate: '', fee: '0.0001', autoLockMin: 15 };
  const views = ['vSetup', 'vBackup', 'vUnlock', 'vHome', 'vSend', 'vSettings', 'vApprove'];
  let cfg = { ...DEFAULT_CFG }, acc = null, wallet = null, approveId = (location.hash.match(/approve=([\w-]+)/) || [])[1] || null, pendingReq = null, builtTx = null;

  const show = v => { views.forEach(x => $(x).hidden = x !== v); $('btnLock').hidden = !(wallet && (v === 'vHome' || v === 'vSend' || v === 'vSettings')); };
  const note = (t, ok) => { const m = $('msg'); m.hidden = !t; m.textContent = t || ''; m.className = 'msg' + (ok ? ' ok' : ''); };
  const el = (tag, props = {}, ...kids) => { const e = document.createElement(tag); Object.assign(e, props); kids.forEach(k => e.append(k)); return e; };
  const kv = (k, v) => el('div', { className: 'kv' }, el('span', { textContent: k }), el('b', { textContent: v }));
  const trimNum = n => (Math.round(n * 1e8) / 1e8).toString();
  const busy = (btn, on, txt) => { btn.disabled = on; if (txt) btn.textContent = on ? 'Memproses…' : txt; };

  // dialog di dalam popup (dialog bawaan browser sering gagal di popup ekstensi)
  const ask = (text, withInput) => new Promise(res => {
    const m = $('modal'), i = $('mInput'); $('mText').textContent = text; i.hidden = !withInput; i.value = ''; m.hidden = false; if (withInput) i.focus();
    const done = v => { m.hidden = true; i.value = ''; res(v); };
    $('mYes').onclick = () => done(withInput ? i.value : true); $('mNo').onclick = () => done(withInput ? null : false);
  });
  const getLocal = async k => (await ext.storage.local.get(k))[k];
  const touch = () => ext.runtime.sendMessage({ type: 'touch' });

  async function init() {
    cfg = { ...DEFAULT_CFG, ...(await getLocal('cfg')) };
    acc = await getLocal('account');
    const sess = (await ext.storage.session.get('wif')).wif;
    if (acc && sess) { wallet = C.walletFromWif(sess, acc.type); touch(); }
    if (approveId) return initApprove();
    if (!acc) return show('vSetup');
    if (!wallet) return show('vUnlock');
    goHome();
  }

  // ---------- setup ----------
  let importMode = false, seedMode = false, setupWif = null;
  const setMode = m => {            // m: 'create' | 'wif' | 'seed'
    importMode = m === 'wif'; seedMode = m === 'seed';
    $('tabCreate').classList.toggle('on', m === 'create'); $('tabImport').classList.toggle('on', m === 'wif'); $('tabSeed').classList.toggle('on', m === 'seed');
    $('importBox').hidden = m !== 'wif'; $('seedBox').hidden = m !== 'seed'; $('seedHint').hidden = m !== 'seed';
  };
  $('tabCreate').onclick = () => setMode('create'); $('tabImport').onclick = () => setMode('wif'); $('tabSeed').onclick = () => setMode('seed');
  $('inSeed').oninput = () => { $('seedCount').textContent = C_SEED.normalizeMnemonic($('inSeed').value).split(' ').filter(Boolean).length + ' kata'; };
  $('btnSetup').onclick = async () => {
    note(''); const b = $('btnSetup');
    try {
      const p1 = $('inPass').value, p2 = $('inPass2').value, type = $('inType').value;
      if (p1.length < 8) throw new Error('Password minimal 8 karakter.');
      if (p1 !== p2) throw new Error('Konfirmasi password tidak sama.');
      if (seedMode) { const c = C_SEED.checkMnemonic($('inSeed').value); if (!c.ok) throw new Error(c.error); }
      busy(b, true);
      const wif = seedMode ? await C_SEED.wifFromMnemonic($('inSeed').value, type) : importMode ? $('inWif').value.trim() : C.wifEncode(C.randomPrivKey());
      const w = C.walletFromWif(wif, type);                       // validasi WIF
      const vault = await C.encryptSecret(p1, wif);
      await ext.storage.local.set({ vault, account: { address: w.address, pubkey: w.pubkey, type }, perms: {} });
      await ext.storage.session.set({ wif });
      acc = { address: w.address, pubkey: w.pubkey, type }; wallet = w; touch();
      $('inPass').value = $('inPass2').value = $('inWif').value = $('inSeed').value = ''; $('seedCount').textContent = '0 kata';
      if (importMode || seedMode) return approveId ? initApprove() : goHome();
      setupWif = wif; $('bkWif').value = wif; $('bkOk').checked = false; $('btnBackupDone').disabled = true; show('vBackup');
    } catch (e) { note(e.message); } finally { busy(b, false, 'Lanjut'); }
  };
  $('bkOk').onchange = () => $('btnBackupDone').disabled = !$('bkOk').checked;
  $('btnBackupDone').onclick = () => { $('bkWif').value = ''; setupWif = null; approveId ? initApprove() : goHome(); };

  // ---------- unlock / lock ----------
  async function doUnlock() {
    note(''); const b = $('btnUnlock');
    try {
      busy(b, true);
      const vault = await getLocal('vault'); const wif = await C.decryptSecret($('unPass').value, vault);
      await ext.storage.session.set({ wif }); wallet = C.walletFromWif(wif, acc.type); touch(); $('unPass').value = '';
      approveId ? initApprove() : goHome();
    } catch (e) { note(e.message); } finally { busy(b, false, 'Buka'); }
  }
  $('btnUnlock').onclick = doUnlock; $('unPass').onkeydown = e => { if (e.key === 'Enter') doUnlock(); };
  $('btnForgot').onclick = async () => {
    if (!(await ask('Wallet di browser ini akan diganti dengan wallet dari seed phrase / WIF yang Anda masukkan. Pastikan Anda punya cadangannya. Lanjutkan?'))) return;
    note(''); setMode('seed'); show('vSetup');
  };
  $('btnLock').onclick = async () => { await ext.storage.session.remove('wif'); wallet = null; note(''); show('vUnlock'); };

  // ---------- home ----------
  async function goHome() {
    note(''); show('vHome'); $('hAddr').textContent = acc.address; $('hBalance').textContent = '…';
    try { $('hBalance').textContent = trimNum(await C.fetchBalance(cfg.explorer, acc.address)) + ' NUX'; } catch (e) { $('hBalance').textContent = 'Offline'; note('Gagal memuat saldo: ' + e.message); }
    const box = $('hHistory'); box.textContent = '';
    try {
      const h = await C.fetchHistory(cfg.explorer, acc.address, 10);
      if (!h.length) box.append(el('small', { textContent: 'Belum ada transaksi.' }));
      h.forEach(t => box.append(el('div', {}, el('a', { href: C.trimUrl(cfg.explorer) + '/tx/' + encodeURIComponent(t.txid), target: '_blank', rel: 'noopener noreferrer', textContent: t.txid.slice(0, 10) + '…' + t.txid.slice(-8) }), el('span', { textContent: t.amount !== null && !isNaN(t.amount) ? trimNum(t.amount) + ' NUX' : '' }))));
    } catch (e) { box.textContent = ''; box.append(el('small', { textContent: 'Riwayat tidak tersedia.' })); }
  }
  $('btnRefresh').onclick = goHome;
  $('btnCopy').onclick = async () => { await navigator.clipboard.writeText(acc.address); note('Alamat disalin.', true); setTimeout(() => note(''), 1500); };
  $('btnToSend').onclick = () => { note(''); $('sTo').value = ''; $('sAmt').value = ''; $('sFee').value = cfg.fee; $('sReview').hidden = true; builtTx = null; $('btnSendGo').textContent = 'Tinjau'; show('vSend'); };
  $('btnToSettings').onclick = openSettings;

  // ---------- kirim ----------
  $('btnSendBack').onclick = goHome;
  $('btnSendGo').onclick = async () => {
    note(''); const b = $('btnSendGo');
    try {
      busy(b, true);
      if (!builtTx) {
        builtTx = await C.prepareSend(cfg, wallet, $('sTo').value.trim(), $('sAmt').value, $('sFee').value);
        const r = $('sReview'); r.textContent = ''; r.hidden = false;
        r.append(kv('Ke', $('sTo').value.trim()), kv('Jumlah', trimNum(Number($('sAmt').value)) + ' NUX'), kv('Fee', trimNum(builtTx.fee) + ' NUX'), kv('Input', String(builtTx.inputs)), el('small', { textContent: 'Transaksi tidak bisa dibatalkan setelah dikirim.' }));
        b.textContent = 'Kirim sekarang'; b.disabled = false; return;
      }
      const txid = await C.broadcast(cfg, builtTx.raw, builtTx.txid);
      builtTx = null; note('Terkirim. TXID: ' + txid, true); goHomeKeepNote();
    } catch (e) { note(e.message); builtTx = null; $('sReview').hidden = true; b.textContent = 'Tinjau'; b.disabled = false; }
  };
  ['sTo', 'sAmt', 'sFee'].forEach(i => $(i).oninput = () => { builtTx = null; $('sReview').hidden = true; $('btnSendGo').textContent = 'Tinjau'; });
  async function goHomeKeepNote() { const t = $('msg').textContent; await goHome(); note(t, true); }

  // ---------- pengaturan ----------
  async function openSettings() {
    note(''); $('cExplorer').value = cfg.explorer; $('cApi').value = cfg.api; $('cUtxo').value = cfg.utxoTemplate; $('cFee').value = cfg.fee; $('cLock').value = cfg.autoLockMin; $('cWif').hidden = true; $('cWif').value = '';
    const perms = (await getLocal('perms')) || {}, box = $('cSites'); box.textContent = '';
    const keys = Object.keys(perms); if (!keys.length) box.append(el('small', { textContent: 'Belum ada situs terhubung.' }));
    keys.forEach(o => box.append(el('div', {}, el('span', { textContent: o }), el('button', { className: 'danger', style: 'width:auto;margin:0', textContent: 'Cabut', onclick: async () => { const p = (await getLocal('perms')) || {}; delete p[o]; await ext.storage.local.set({ perms: p }); openSettings(); } }))));
    show('vSettings');
  }
  $('btnSetBack').onclick = goHome;
  $('btnSaveCfg').onclick = async () => {
    const u = x => { const v = x.trim(); if (v && !/^https:\/\//i.test(v)) throw new Error('URL harus diawali https://'); return v; };
    try {
      cfg = { explorer: u($('cExplorer').value) || DEFAULT_CFG.explorer, api: u($('cApi').value) || DEFAULT_CFG.api, utxoTemplate: u($('cUtxo').value), fee: $('cFee').value || DEFAULT_CFG.fee, autoLockMin: Number($('cLock').value) || 15 };
      await ext.storage.local.set({ cfg }); note('Tersimpan. Jika memakai domain baru, tambahkan di host_permissions manifest.', true);
    } catch (e) { note(e.message); }
  };
  $('btnExport').onclick = async () => {
    const pw = await ask('Masukkan password untuk menampilkan private key:', true); if (pw === null) return;
    try { $('cWif').value = await C.decryptSecret(pw, await getLocal('vault')); $('cWif').hidden = false; setTimeout(() => { $('cWif').value = ''; $('cWif').hidden = true; }, 30000); } catch (e) { note(e.message); }
  };
  $('btnReset').onclick = async () => {
    if (!(await ask('Hapus wallet dari browser ini? Tanpa cadangan seed phrase/WIF, dana tidak bisa dipulihkan.'))) return;
    await ext.storage.local.remove(['vault', 'account', 'perms']); await ext.storage.session.remove('wif'); acc = wallet = null; note(''); show('vSetup');
  };

  // ---------- persetujuan DApp ----------
  async function initApprove() {
    note('');
    setInterval(() => { ext.runtime.sendMessage({ type: 'ping' }).catch(() => {}); }, 15000); // jaga background tetap hidup selama menunggu persetujuan
    pendingReq = await ext.runtime.sendMessage({ type: 'get-pending', id: approveId });
    if (!pendingReq) { show('vApprove'); $('aTitle').textContent = 'Permintaan tidak ditemukan'; $('aBody').textContent = ''; $('btnApprove').hidden = $('btnReject').hidden = true; return; }
    if (!acc) return show('vSetup');
    if (pendingReq.method !== 'nux_connect' && !wallet) return show('vUnlock');
    const r = pendingReq, body = $('aBody'); body.textContent = ''; $('aOrigin').textContent = r.origin; $('btnApprove').disabled = false; $('btnApprove').hidden = $('btnReject').hidden = false; builtTx = null;
    show('vApprove');
    if (r.method === 'nux_connect') {
      $('aTitle').textContent = 'Hubungkan situs'; body.append(el('p', { textContent: 'Situs ini meminta melihat alamat dan public key Anda. Ia tidak bisa mengirim dana tanpa persetujuan Anda.' }), kv('Alamat', acc.address));
    } else if (r.method === 'nux_signMessage') {
      $('aTitle').textContent = 'Tanda tangani pesan'; body.append(el('small', { textContent: 'Pesan:' }), el('pre', { textContent: r.params.message }), el('p', { className: 'hint', textContent: 'Tanda tangan tidak memindahkan dana, tapi bisa dipakai situs untuk membuktikan Anda pemilik alamat.' }));
    } else if (r.method === 'nux_sendTransaction') {
      $('aTitle').textContent = 'Kirim NUX'; body.append(el('small', { textContent: 'Menyiapkan transaksi…' })); $('btnApprove').disabled = true;
      try {
        builtTx = await C.prepareSend(cfg, wallet, r.params.to, r.params.amount, cfg.fee);
        body.textContent = ''; body.append(kv('Ke', r.params.to), kv('Jumlah', trimNum(Number(r.params.amount)) + ' NUX'), kv('Fee', trimNum(builtTx.fee) + ' NUX'), el('p', { className: 'hint', textContent: 'Periksa alamat tujuan dengan teliti. Transaksi tidak bisa dibatalkan.' }));
        $('btnApprove').disabled = false;
      } catch (e) { body.textContent = ''; note(e.message); }
    } else if (r.method === 'nux_signTransaction') {
      $('aTitle').textContent = 'Tanda tangani transaksi'; body.append(el('small', { textContent: 'Memverifikasi transaksi…' })); $('btnApprove').disabled = true;
      try {
        builtTx = await C.prepareSign(cfg, wallet, r.params.inputs, r.params.outputs);
        const outs = builtTx.outputs, pay = outs.filter(o => !o.script.startsWith('6a'));
        const others = pay.filter(o => C.scriptToAddress(o.script) !== acc.address), sumOthers = others.reduce((a, o) => a + o.value, 0);
        const short = a => a.length > 26 ? a.slice(0, 12) + '…' + a.slice(-8) : a;
        body.textContent = '';
        body.append(kv('Input', builtTx.inputs + ' UTXO (' + trimNum(builtTx.totalIn / 1e8) + ' NUX)'), kv('Keluar ke pihak lain', trimNum(sumOthers / 1e8) + ' NUX'), kv('Fee', trimNum(builtTx.fee) + ' NUX'));
        others.slice(0, 8).forEach(o => body.append(kv(short(C.scriptToAddress(o.script)), trimNum(o.value / 1e8) + ' NUX')));
        if (others.length > 8) body.append(el('small', { textContent: '…dan ' + (others.length - 8) + ' output lain ke pihak lain.' }));
        if (!others.length) body.append(el('p', { className: 'hint', textContent: 'Tidak ada NUX yang keluar ke pihak lain (hanya ke wallet sendiri dan/atau data on-chain).' }));
        const opd = outs.map(o => C.opReturnData(o.script)).find(Boolean);
        if (opd) { let t = ''; try { t = new TextDecoder('utf-8', { fatal: true }).decode(opd); } catch (_) {} body.append(el('small', { textContent: 'Data on-chain (' + opd.length + ' byte):' }), el('pre', { textContent: t || C.bytesToHex(opd) })); }
        body.append(el('p', { className: 'hint', textContent: 'Situs akan menyiarkan transaksi ini setelah Anda setujui. Periksa tujuan dan jumlah dengan teliti; transaksi tidak bisa dibatalkan.' }));
        $('btnApprove').disabled = false;
      } catch (e) { body.textContent = ''; note(e.message); }
    } else if (r.method === 'nux_sendData') {
      $('aTitle').textContent = 'Tulis data ke blockchain'; body.append(el('small', { textContent: 'Menyiapkan transaksi…' })); $('btnApprove').disabled = true;
      try {
        const bytes = C.hexToBytes(r.params.hex);
        builtTx = await C.prepareData(cfg, wallet, bytes, cfg.fee);
        let preview = ''; try { preview = new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (_) {}
        body.textContent = ''; body.append(kv('Ukuran', bytes.length + ' byte'), kv('Fee', trimNum(builtTx.fee) + ' NUX'), el('small', { textContent: 'Data (hex):' }), el('pre', { textContent: r.params.hex }));
        if (preview) body.append(el('small', { textContent: 'Teks:' }), el('pre', { textContent: preview }));
        body.append(el('p', { className: 'hint', textContent: 'Data ini akan tercatat permanen dan publik di blockchain. Tidak ada NUX yang dikirim ke pihak lain selain fee.' }));
        $('btnApprove').disabled = false;
      } catch (e) { body.textContent = ''; note(e.message); }
    }
  }
  $('btnReject').onclick = async () => { await ext.runtime.sendMessage({ type: 'resolve-pending', id: approveId, approved: false }); window.close(); };
  $('btnApprove').onclick = async () => {
    const r = pendingReq, b = $('btnApprove'); note('');
    try {
      busy(b, true); let result = null;
      if (r.method === 'nux_signMessage') result = C.signMessage(wallet.wif, r.params.message);
      else if (r.method === 'nux_signTransaction') result = { raw: builtTx.raw, txid: builtTx.txid, fee: builtTx.fee };
      else if (r.method === 'nux_sendTransaction' || r.method === 'nux_sendData') result = { txid: await C.broadcast(cfg, builtTx.raw, builtTx.txid) };
      await ext.runtime.sendMessage({ type: 'resolve-pending', id: approveId, approved: true, result }); window.close();
    } catch (e) { note(e.message); busy(b, false, 'Setujui'); }
  };
  window.addEventListener('beforeunload', () => {}); // jendela ditutup = ditolak (ditangani service worker)

  init();
})();
