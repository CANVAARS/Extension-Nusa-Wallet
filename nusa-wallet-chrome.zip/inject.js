// Berjalan di konteks halaman: menyediakan window.nux untuk DApp.
(function () {
  if (window.nux) return;
  const pending = new Map(); let seq = 0; const listeners = {};
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.target !== 'nusa-page') return;
    const m = e.data;
    if (m.event) { (listeners[m.event] || []).forEach(fn => { try { fn(m.data); } catch (_) {} }); return; }
    const p = pending.get(m.id); if (!p) return; pending.delete(m.id);
    m.error ? p.reject(Object.assign(new Error(m.error.message), { code: m.error.code })) : p.resolve(m.result);
  });
  function request(args) {
    if (!args || typeof args.method !== 'string') return Promise.reject(new Error('method wajib diisi'));
    return new Promise((resolve, reject) => {
      const id = ++seq; pending.set(id, { resolve, reject });
      window.postMessage({ target: 'nusa-content', id, method: args.method, params: args.params || {} }, window.location.origin);
    });
  }
  const nux = Object.freeze({
    isNuxWallet: true, chain: 'nusacoin', symbol: 'NUX',
    request,
    connect: () => request({ method: 'nux_connect' }),                  // -> { address, publicKey }
    disconnect: () => request({ method: 'nux_disconnect' }),
    getAddress: () => request({ method: 'nux_getAddress' }),
    getBalance: () => request({ method: 'nux_getBalance' }),            // -> NUX (number)
    signMessage: message => request({ method: 'nux_signMessage', params: { message: String(message) } }),
    sendTransaction: ({ to, amount }) => request({ method: 'nux_sendTransaction', params: { to, amount } }), // amount dalam NUX
    // data: string (utf8) atau hex; encoding: 'utf8' (default) | 'hex'. Maks 80 byte. -> { txid }
    // inputs: [{txid, vout}] (nilai input diverifikasi extension), outputs: [{script(hex), value(satoshi)}]. -> { raw, txid, fee } (belum disiarkan)
    signTransaction: ({ inputs, outputs }) => request({ method: 'nux_signTransaction', params: { inputs, outputs } }),
    sendData: ({ data, encoding = 'utf8' }) => request({ method: 'nux_sendData', params: { data: String(data), encoding } }),
    on: (ev, fn) => { (listeners[ev] = listeners[ev] || []).push(fn); },
    off: (ev, fn) => { listeners[ev] = (listeners[ev] || []).filter(f => f !== fn); }
  });
  Object.defineProperty(window, 'nux', { value: nux, writable: false, configurable: false });
  if (!window.nusa) Object.defineProperty(window, 'nusa', { value: nux, writable: false, configurable: false }); // alias
  window.dispatchEvent(new Event('nux#initialized'));
  window.dispatchEvent(new Event('nusa#initialized'));
})();
