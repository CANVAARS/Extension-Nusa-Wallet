// Jembatan: halaman <-> service worker. Hanya meneruskan method yang diizinkan.
(function () {
  const ext = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome; // Firefox: browser.*, Chrome/Edge: chrome.*
  const s = document.createElement('script'); s.src = ext.runtime.getURL('inject.js');
  s.onload = () => s.remove(); (document.head || document.documentElement).appendChild(s);
  const ALLOWED = ['nux_connect', 'nux_disconnect', 'nux_getAddress', 'nux_getBalance', 'nux_signMessage', 'nux_sendTransaction', 'nux_sendData', 'nux_signTransaction'];
  window.addEventListener('message', async e => {
    if (e.source !== window || !e.data || e.data.target !== 'nusa-content') return;
    const { id, method, params } = e.data;
    const reply = o => window.postMessage(Object.assign({ target: 'nusa-page', id }, o), window.location.origin);
    if (!ALLOWED.includes(method)) return reply({ error: { code: 4200, message: 'Method tidak didukung: ' + method } });
    try {
      const res = await ext.runtime.sendMessage({ type: 'dapp-request', method, params, origin: window.location.origin });
      res && res.error ? reply({ error: res.error }) : reply({ result: res ? res.result : null });
    } catch (err) { reply({ error: { code: -32603, message: err.message } }); }
  });
  ext.runtime.onMessage.addListener(m => { if (m && m.type === 'dapp-event') window.postMessage({ target: 'nusa-page', event: m.event, data: m.data }, window.location.origin); });
})();
